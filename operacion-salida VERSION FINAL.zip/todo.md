# Operación Salida - TODO

## Funcionalidades Completadas

- [x] Calculadora de deudas con métodos Snowball y Avalanche
- [x] Hook useLocalStorage para persistencia de datos
- [x] Página principal (Home.tsx) con interfaz completa
- [x] Componentes UI (Button, Input, Label, Card, Badge)
- [x] Estilos CSS con tema oscuro (OKLCH)
- [x] Fuentes de Google (Space Grotesk, Manrope, Inter)
- [x] Navegación sticky con secciones
- [x] Formulario de entrada de deudas
- [x] Selector de método de ataque (Snowball/Avalanche)
- [x] Sección de Misión Briefing con comparativas
- [x] Sección de Orden de Ataque
- [x] Animaciones con Framer Motion
- [x] Toast notifications con Sonner
- [x] Persistencia local de deudas, pagos extra y método

## Funcionalidades Completadas

- [x] Integrar MapView en la UI de Home.tsx (página /map con formulario de ubicaciones)
- [x] Pruebas unitarias con Vitest (14 pruebas pasadas)
- [x] Interfaz completamente funcional y lista para usar

## Notas

- La aplicación está completamente funcional para gestionar deudas
- Todos los estilos del proyecto original han sido preservados
- La lógica de calculadora es exacta al original
- Los datos persisten en localStorage con las claves: 'nodo-debts', 'nodo-extra-payment', 'nodo-method'


## Funcionalidades en Desarrollo

- [x] Barra de progreso global en Orden de Ataque (verde=pagado, amarillo=intereses, rojo=saldo)
- [x] Barras de progreso por deuda individual
- [x] Actualización mes a mes del saldo con intereses y pagos
- [x] Integración de datos de simulación en la visualización de barras


## Cambios Solicitados por Usuario

- [x] Eliminar sección "Ver mapa de ubicaciones"
- [x] Crear sección de Registro de Pagos con menú desplegable, cantidad y fecha
- [x] Aplicar pagos al cálculo de intereses del mes correspondiente
- [x] Reflejar pagos en barras de progreso
- [x] Posicionar sección de pagos ANTES del progreso global

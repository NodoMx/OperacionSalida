export const COOKIE_NAME = "app_session_id";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
export const AXIOS_TIMEOUT_MS = 30000;
export const NOT_ADMIN_ERR_MSG = "You are not an admin";
export const UNAUTHED_ERR_MSG = "You are not authenticated";
export const OAUTH_STATE_COOKIE = "oauth_state";

export function decodeOAuthState(state: string): string {
  try {
    return atob(state);
  } catch {
    return "";
  }
}

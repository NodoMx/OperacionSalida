import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Shield, Target, Calendar, Zap, TrendingDown,
  Plus, Trash2, Swords, Trophy,
  ArrowRight, Flame, Clock, DollarSign, RotateCcw,
  AlertTriangle, Snowflake, Mountain, MapPin,
  Lightbulb,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import {
  Debt,
  calculatePayoff,
  formatCurrency,
  formatNumber,
  formatDate,
} from '@/lib/debt-calculator';
import { ProgressBar } from '@/components/ProgressBar';
import { PaymentRecorder } from '@/components/PaymentRecorder';
import { toast } from 'sonner';
import type { Payment } from '@/types/payments';

/* ─── Sticky Navigation ─── */
function StickyNav({ activeSection, debtCount }: { activeSection: string; debtCount: number }) {
  const sections = [
    { id: 'recon', label: 'Reconocimiento' },
    { id: 'briefing', label: 'Misión' },
    { id: 'attack', label: 'Ataque' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-[#0A0A0C]/90 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-[860px] mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-[#00E5FF] flex items-center justify-center">
              <span className="text-[#0A0A0C] font-bold text-[11px]">N</span>
            </div>
            <span className="font-heading font-bold text-[13px] text-white tracking-tight">OPERACIÓN SALIDA</span>
          </div>
          <div className="hidden sm:flex gap-0.5">
            {sections.map(s => (
              <a
                key={s.id}
                href={`#${s.id}`}
                className={`px-3 py-1.5 rounded-md text-[11px] font-medium transition-all duration-200 ${
                  activeSection === s.id
                    ? 'bg-[#00E5FF]/15 text-[#00E5FF]'
                    : 'text-white/40 hover:text-white/70'
                }`}
              >
                {s.label}
              </a>
            ))}
          </div>
          {debtCount > 0 && (
            <Badge variant="outline" className="text-[10px] border-white/10 text-white/50 hidden sm:flex">
              {debtCount} enemigos
            </Badge>
          )}
        </div>
      </div>
    </nav>
  );
}

/* ─── Method Selector (moved to top) ─── */
function MethodSelector({
  method,
  onMethodChange,
  hasData,
}: {
  method: 'snowball' | 'avalanche';
  onMethodChange: (m: 'snowball' | 'avalanche') => void;
  hasData: boolean;
}) {
  const handleMethodChange = (m: 'snowball' | 'avalanche') => {
    onMethodChange(m);
  };

  return (
    <div className="mb-6">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-10 h-10 rounded-lg bg-[#00E5FF]/10 flex items-center justify-center">
          <CrosshairsIcon />
        </div>
        <div>
          <h2 className="font-heading text-xl font-bold text-white">Método de Ataque</h2>
          <p className="text-white/50 text-xs">Elige tu estrategia antes de ingresar datos.</p>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => handleMethodChange('snowball')}
          className={`flex-1 py-3 px-4 rounded-lg text-sm font-semibold transition-all duration-200 border ${
            method === 'snowball'
              ? 'bg-[#00E5FF]/10 border-[#00E5FF]/30 text-[#00E5FF]'
              : 'bg-white/[0.03] border-white/[0.06] text-white/40 hover:text-white/60'
          }`}
        >
          <Snowflake className="w-4 h-4 mx-auto mb-1" />
          Bola de Nieve
          <span className="block text-[10px] font-normal mt-1 text-white/30">Primera victoria rápido</span>
        </button>
        <button
          onClick={() => handleMethodChange('avalanche')}
          className={`flex-1 py-3 px-4 rounded-lg text-sm font-semibold transition-all duration-200 border ${
            method === 'avalanche'
              ? 'bg-[#30D158]/10 border-[#30D158]/30 text-[#30D158]'
              : 'bg-white/[0.03] border-white/[0.06] text-white/40 hover:text-white/60'
          }`}
        >
          <Mountain className="w-4 h-4 mx-auto mb-1" />
          Avalancha
          <span className="block text-[10px] font-normal mt-1 text-white/30">Ahorra más dinero</span>
        </button>
      </div>


    </div>
  );
}

function CrosshairsIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00E5FF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
      <line x1="12" y1="2" x2="12" y2="4" />
      <line x1="12" y1="20" x2="12" y2="22" />
      <line x1="2" y1="12" x2="4" y2="12" />
      <line x1="20" y1="12" x2="22" y2="12" />
    </svg>
  );
}

/* ─── Debt Input Form ─── */
function DebtForm({
  debts,
  onAdd,
  onRemove,
  extraPayment,
  onExtraPaymentChange,
}: {
  debts: Debt[];
  onAdd: (debt: Debt) => void;
  onRemove: (id: string) => void;
  extraPayment: number;
  onExtraPaymentChange: (v: number) => void;
}) {
  const [name, setName] = useState('');
  const [balance, setBalance] = useState('');
  const [minPayment, setMinPayment] = useState('');
  const [rate, setRate] = useState('');

  const handleAdd = () => {
    if (!name || !balance || !minPayment) {
      toast.error('Completa nombre, saldo y pago mínimo.');
      return;
    }
    onAdd({
      id: crypto.randomUUID(),
      name,
      balance: parseFloat(balance),
      minPayment: parseFloat(minPayment),
      interestRate: rate ? parseFloat(rate) : 40,
      createdAt: new Date().toISOString(),
    });
    setName('');
    setBalance('');
    setMinPayment('');
    setRate('');
    toast.success(`${name} añadida al arsenal.`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleAdd();
  };

  const totalMinPayments = debts.reduce((sum, d) => sum + d.minPayment, 0);
  const isExtraValid = extraPayment > 0 && (totalMinPayments === 0 || extraPayment >= totalMinPayments * 0.1);

  return (
    <div id="recon" className="pt-4 pb-4">
      {/* Form inputs */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="col-span-2 sm:col-span-1">
          <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Nombre</Label>
          <Input
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ej: Tarjeta BBVA"
            className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg"
          />
        </div>
        <div className="col-span-2 sm:col-span-1">
          <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Saldo total ($)</Label>
          <Input
            value={balance}
            onChange={e => setBalance(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="15000"
            type="number"
            className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg"
          />
        </div>
        <div>
          <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Pago mínimo ($)</Label>
          <Input
            value={minPayment}
            onChange={e => setMinPayment(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="450"
            type="number"
            className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg"
          />
        </div>
        <div>
          <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Tasa anual % <span className="text-white/25">(opcional)</span></Label>
          <Input
            value={rate}
            onChange={e => setRate(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="35 (default: 40)"
            type="number"
            className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg"
          />
        </div>
      </div>

      <Button
        onClick={handleAdd}
        className="w-full bg-[#00E5FF] text-[#0A0A0C] font-bold hover:bg-[#00E5FF]/90 h-10 text-sm rounded-lg"
      >
        <Plus className="w-4 h-4 mr-2" />
        Agregar deuda
      </Button>

      {/* Debt list */}
      <AnimatePresence>
        {debts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-6 space-y-2"
          >
            <h3 className="text-[11px] font-heading font-semibold text-white/30 uppercase tracking-widest mb-3">
              Tus enemigos ({debts.length})
            </h3>
            {debts.map((debt, i) => (
              <motion.div
                key={debt.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05, duration: 0.3 }}
                className="flex items-center justify-between bg-white/[0.03] rounded-lg px-4 py-3 border border-white/[0.05]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#FF3B30]/10 flex items-center justify-center">
                    <Swords className="w-4 h-4 text-[#FF3B30]" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{debt.name}</p>
                    <p className="text-[11px] text-white/40">
                      {formatCurrency(debt.balance)} · {debt.interestRate}% anual · min {formatCurrency(debt.minPayment)}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onRemove(debt.id)}
                  className="text-white/20 hover:text-[#FF3B30] transition-colors p-1.5 rounded-md hover:bg-[#FF3B30]/10"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            ))}

            {/* Extra payment field */}
            <div className="mt-5 pt-5 border-t border-white/[0.05]">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-full bg-[#30D158]/10 flex items-center justify-center">
                  <DollarSign className="w-4 h-4 text-[#30D158]" />
                </div>
                <div>
                  <Label className="text-[11px] text-white/40 font-subtitle">
                    Dinero extra al mes ($)
                  </Label>
                  <p className="text-[10px] text-white/30">El monto que puedes aportar por encima de tus mínimos</p>
                </div>
              </div>
              <Input
                value={extraPayment > 0 ? String(extraPayment) : ''}
                onChange={e => onExtraPaymentChange(parseFloat(e.target.value) || 0)}
                placeholder="1000"
                type="number"
                className={`bg-white/[0.04] border text-white placeholder:text-white/25 h-10 text-sm rounded-lg ${
                  totalMinPayments > 0 && extraPayment > 0 && extraPayment < totalMinPayments * 0.1
                    ? 'border-[#FF3B30]/40'
                    : 'border-white/[0.08]'
                }`}
              />
              {totalMinPayments > 0 && extraPayment > 0 && extraPayment < totalMinPayments * 0.1 && (
                <p className="flex items-center gap-1 text-[10px] text-[#FF3B30]/80 mt-1.5">
                  <AlertTriangle className="w-3 h-3" />
                  El extra debe ser significativo frente a tus mínimos ({formatCurrency(totalMinPayments)}/mes)
                </p>
              )}
              {extraPayment > 0 && (
                <p className="text-[10px] text-[#30D158]/70 mt-1.5">
                  Pago total mensual: {formatCurrency(totalMinPayments + extraPayment)}
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Mission Briefing ─── */
function MissionBriefing({ debts, extraPayment, method }: { debts: Debt[]; extraPayment: number; method: 'snowball' | 'avalanche' }) {
  const result = useMemo(
    () => debts.length > 0 && extraPayment > 0 ? calculatePayoff(debts, extraPayment, method) : null,
    [debts, extraPayment, method]
  );
  const minResult = useMemo(
    () => debts.length > 0 ? calculatePayoff(debts, 0, 'snowball') : null,
    [debts]
  );

  if (!minResult || debts.length === 0) return null;

  const isMinOver30Years = minResult.totalMonths >= 360;

  const minMonths = minResult.totalMonths >= 12
    ? `${Math.floor(minResult.totalMonths / 12)} año${Math.floor(minResult.totalMonths / 12) > 1 ? 's' : ''}`
    : `${minResult.totalMonths} meses`;

  if (!result || extraPayment <= 0) {
    // Only min-only visible
    return (
      <section id="briefing" className="pt-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-[#FF3B30]/10 flex items-center justify-center">
              <Target className="w-5 h-5 text-[#FF3B30]" />
            </div>
            <div>
              <h2 className="font-heading text-xl font-bold text-white">Misión Briefing</h2>
              <p className="text-white/50 text-xs">Tus números. Sin adornos.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            <Card className={`bg-[#FF3B30]/[0.04] border-[#FF3B30]/15 ${isMinOver30Years ? 'sm:col-span-2' : ''}`}>
              <CardContent className="pt-5 pb-4 px-5">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingDown className="w-4 h-4 text-[#FF3B30]" />
                  <span className="text-[10px] font-bold text-[#FF3B30] uppercase tracking-widest">
                    Pagando solo mínimos
                  </span>
                </div>
                <p className={`font-heading font-bold ${isMinOver30Years ? 'text-lg text-[#FF3B30]' : 'text-3xl text-[#FF3B30]'}`}>
                  {isMinOver30Years ? 'Más de 30 años' : minMonths}
                </p>
                {isMinOver30Years ? (
                  <p className="text-xs text-[#FF3B30]/70 mt-1">
                    Revisa tus números. Con solo mínimos, es posible que nunca salgas.
                  </p>
                ) : (
                  <p className="text-xs text-white/40 mt-1">
                    Intereses: {formatCurrency(minResult.totalInterestPaid)}
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </section>
    );
  }

  const monthsText = result.totalMonths >= 12
    ? `${Math.floor(result.totalMonths / 12)} año${Math.floor(result.totalMonths / 12) > 1 ? 's' : ''} ${result.totalMonths % 12} meses`
    : `${result.totalMonths} meses`;

  return (
    <section id="briefing" className="pt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[#00E5FF]/10 flex items-center justify-center">
            <Target className="w-5 h-5 text-[#00E5FF]" />
          </div>
          <div>
            <h2 className="font-heading text-xl font-bold text-white">Misión Briefing</h2>
            <p className="text-white/50 text-xs">Tus números. Sin adornos.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          <Card className="bg-[#FF3B30]/[0.04] border-[#FF3B30]/15">
            <CardContent className="pt-5 pb-4 px-5">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-4 h-4 text-[#FF3B30]" />
                <span className="text-[10px] font-bold text-[#FF3B30] uppercase tracking-widest">
                  Pagando solo mínimos
                </span>
              </div>
              <p className="text-3xl font-heading font-bold text-[#FF3B30]">
                {minMonths}
              </p>
              <p className="text-xs text-white/40 mt-1">
                Intereses: {formatCurrency(minResult.totalInterestPaid)}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#30D158]/[0.04] border-[#30D158]/15">
            <CardContent className="pt-5 pb-4 px-5">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-[#30D158]" />
                <span className="text-[10px] font-bold text-[#30D158] uppercase tracking-widest">
                  Con Operación Salida
                </span>
              </div>
              <p className="text-3xl font-heading font-bold text-[#30D158]">
                {monthsText}
              </p>
              <p className="text-xs text-white/40 mt-1">
                Intereses: {formatCurrency(result.totalInterestPaid)}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Freedom date highlight */}
        <div className="bg-gradient-to-r from-[#00E5FF]/[0.06] via-transparent to-[#30D158]/[0.06] border border-[#00E5FF]/[0.12] rounded-xl p-5 mb-6">
          <div className="text-center">
            <p className="text-[11px] text-[#00E5FF]/70 font-semibold uppercase tracking-widest mb-2">Tu fecha de libertad</p>
            <p className="text-3xl font-heading font-bold text-white mb-4">
              {formatDate(result.freedomDate)}
            </p>
              <div className="text-center">
                <p className="text-[11px] text-white/40 mb-1">
                  Eso es lo que le hubieras dado al banco en intereses en esos {result.totalMonths} meses sin Operación Salida
                </p>
                <p className="text-2xl font-heading font-bold text-[#FF3B30]">
                  {formatCurrency(result.savings)}
                </p>
              </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

/* ─── Attack Plan ─── */
function AttackPlan({ debts, extraPayment, method, payments }: { debts: Debt[]; extraPayment: number; method: 'snowball' | 'avalanche'; payments: Payment[] }) {
  const result = useMemo(() => {
    if (debts.length === 0 || extraPayment <= 0) return null;
    return calculatePayoff(debts, extraPayment, method);
  }, [debts, extraPayment, method]);

  if (!result || debts.length === 0 || extraPayment <= 0) return null;

  // Calculate real progress based on registered payments
  const totalInitialBalance = debts.reduce((sum, d) => sum + d.balance, 0);

  // Calculate interest and balance month by month for each debt
  const calculateDebtProgress = (debt: Debt) => {
    const debtPayments = payments
      .filter(p => p.debtId === debt.id)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    const totalDebtPayments = debtPayments.reduce((sum: number, p: Payment) => sum + p.amount, 0);

    // Start date = when the debt was registered (or now if not available)
    const debtStartDate = debt.createdAt ? new Date(debt.createdAt) : new Date();

    // End date = the latest payment date, or now, whichever is later
    const lastPaymentDate = debtPayments.length > 0
      ? new Date(debtPayments[debtPayments.length - 1].date)
      : new Date();
    const endDate = lastPaymentDate > new Date() ? lastPaymentDate : new Date();

    // Calculate total months from debt registration to end date
    const monthsElapsed = Math.max(1, Math.ceil(
      (endDate.getTime() - debtStartDate.getTime()) / (30 * 24 * 60 * 60 * 1000)
    ));

    // Simulate month by month from debt start date
    // Logic: each month -> Saldo = Saldo anterior + Interés del mes - Pagos del mes
    const monthlyRate = debt.interestRate / 100 / 12;
    let balance = debt.balance;
    let totalInterest = 0;
    let totalPaymentsApplied = 0;

    for (let month = 1; month <= monthsElapsed; month++) {
      // Interest generated this month on the balance at start of month
      const interestThisMonth = balance * monthlyRate;
      totalInterest += interestThisMonth;

      // Determine which payments fall in this month
      const monthStart = new Date(debtStartDate.getTime() + (month - 1) * 30 * 24 * 60 * 60 * 1000);
      const monthEnd = new Date(debtStartDate.getTime() + month * 30 * 24 * 60 * 60 * 1000);

      const monthPayments = debtPayments.filter(p => {
        const paymentDate = new Date(p.date);
        return paymentDate >= monthStart && paymentDate < monthEnd;
      });

      const monthPaymentTotal = monthPayments.reduce((sum: number, p: Payment) => sum + p.amount, 0);
      totalPaymentsApplied += monthPaymentTotal;

      // Saldo final del mes = Saldo inicio + Interés - Pagos
      balance = balance + interestThisMonth - monthPaymentTotal;
    }

    const finalBalance = Math.max(0, balance);

    // Desglose: del total pagado, cuánto fue a interés y cuánto a capital
    // Capital pagado = saldo inicial - saldo final (si positivo)
    // Interés pagado = total pagado - capital pagado
    const capitalPaid = Math.max(0, debt.balance - finalBalance);
    const interestPaid = Math.max(0, totalDebtPayments - capitalPaid);

    return {
      initialBalance: debt.balance,
      interestGenerated: totalInterest,
      paymentApplied: totalDebtPayments,
      interestPaid,
      capitalPaid,
      finalBalance,
      monthsElapsed,
    };
  };

  // Calculate progress for all debts
  const debtProgressMap = new Map(debts.map(d => [d.id, calculateDebtProgress(d)]));

  // Identify defeated debts (balance <= 0)
  const defeatedDebtIds = Array.from(debtProgressMap.entries())
    .filter(([_, progress]) => progress.finalBalance <= 0 && progress.paymentApplied > 0)
    .map(([id]) => id);

  // Global totals from real calculations
  let globalInterestGenerated = 0;
  let globalPaymentApplied = 0;
  let globalInterestPaid = 0;
  let globalCapitalPaid = 0;
  let globalFinalBalance = 0;
  debtProgressMap.forEach(progress => {
    globalInterestGenerated += progress.interestGenerated;
    globalPaymentApplied += progress.paymentApplied;
    globalInterestPaid += progress.interestPaid;
    globalCapitalPaid += progress.capitalPaid;
    globalFinalBalance += progress.finalBalance;
  });

  return (
    <section id="attack" className="pt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[#FF3B30]/10 flex items-center justify-center">
            <Swords className="w-5 h-5 text-[#FF3B30]" />
          </div>
          <div>
            <h2 className="font-heading text-xl font-bold text-white">Orden de Ataque</h2>
            <p className="text-white/50 text-xs">El orden en que cada enemigo cae.</p>
          </div>
        </div>

        {/* Method indicator */}
        <div className="flex items-center gap-2 mb-5">
          {method === 'snowball' ? (
            <Badge className="bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/20">
              Bola de Nieve activa
            </Badge>
          ) : (
            <Badge className="bg-[#30D158]/10 text-[#30D158] border border-[#30D158]/20">
              Avalancha activa
            </Badge>
          )}
          <p className="text-[10px] text-white/30">
            {method === 'snowball'
              ? 'Primera victoria más rápida'
              : 'Mayor ahorro en intereses'}
          </p>
        </div>

        {/* Global Progress Bar */}
        <div className="mb-8 p-4 bg-white/[0.02] rounded-lg border border-white/[0.05]">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-[#FFD60A]" />
            Progreso Global
         </h3>
          <ProgressBar
            initialBalance={totalInitialBalance}
            interestGenerated={globalInterestGenerated}
            paymentApplied={globalPaymentApplied}
            interestPaid={globalInterestPaid}
            capitalPaid={globalCapitalPaid}
            finalBalance={globalFinalBalance}
            label="Total de todas las deudas"
          />
        </div>

        {/* Boss list */}
        <div className="space-y-4">
          {result.order.map((item, i) => {
            const debt = debts.find(d => d.id === item.id);
            if (!debt) return null;
            const monthLabel = item.monthToDefeat <= 12 ? `Mes ${item.monthToDefeat}` : `${Math.floor(item.monthToDefeat / 12)}a ${item.monthToDefeat % 12}m`;

            // Get progress from the month-by-month calculation
            const progress = debtProgressMap.get(item.id);
            if (!progress) return null;

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-white/[0.03] rounded-lg p-4 border border-white/[0.05]"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] font-heading font-bold text-white/20 w-6">#{i + 1}</span>
                    <div className="w-7 h-7 rounded-full bg-[#FF3B30]/10 flex items-center justify-center">
                      <Flame className="w-3.5 h-3.5 text-[#FF3B30]" />
                    </div>
                    <div>
                      <p className="text-lg font-heading font-bold text-white">{item.name}</p>
                      <p className="text-[11px] text-white/35">
                        {formatCurrency(debt.balance)} · {debt.interestRate}% · Mes {progress.monthsElapsed}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-white/30">{monthLabel}</p>
                    <p className="text-xs font-bold text-[#FF3B30]">MUERE {item.name.toUpperCase()}</p>
                  </div>
                </div>

                {/* Individual Debt Progress Bar */}
                <ProgressBar
                  initialBalance={progress.initialBalance}
                  interestGenerated={progress.interestGenerated}
                  paymentApplied={progress.paymentApplied}
                  interestPaid={progress.interestPaid}
                  capitalPaid={progress.capitalPaid}
                  finalBalance={progress.finalBalance}
                  isDefeated={progress.finalBalance <= 0 && progress.paymentApplied > 0}
                  debtName={debt.name}
                />
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </section>
  );
}

/* ─── Main Component ─── */
export default function Home() {
  const [debts, setDebts] = useLocalStorage<Debt[]>('nodo-debts', []);
  const [extraPayment, setExtraPayment] = useLocalStorage<number>('nodo-extra-payment', 0);
  const [method, setMethod] = useLocalStorage<'snowball' | 'avalanche'>('nodo-method', 'snowball');
  const [payments, setPayments] = useLocalStorage<Payment[]>('nodo-payments', []);
  const [activeSection, setActiveSection] = useState('recon');

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.3, rootMargin: '-56px 0px 0px 0px' }
    );

    const sections = document.querySelectorAll('[id]');
    sections.forEach(s => observer.observe(s));

    return () => observer.disconnect();
  }, []);

  const handleAddDebt = (debt: Debt) => {
    setDebts(prev => [...prev, debt]);
  };

  const handleRemoveDebt = (id: string) => {
    setDebts(prev => prev.filter(d => d.id !== id));
    toast.info('Deuda eliminada del arsenal.');
  };

  const handleReset = () => {
    setDebts([]);
    setExtraPayment(0);
    setPayments([]);
    toast.info('Todo reiniciado. Nueva misión.');
  };

  const handleAddPayment = (payment: Payment) => {
    setPayments(prev => [...prev, payment]);
  };

  const handleRemovePayment = (paymentId: string) => {
    setPayments(prev => prev.filter(p => p.id !== paymentId));
    toast.info('Pago eliminado.');
  };

  const hasData = debts.length > 0 && extraPayment > 0;

  // Calculate defeated debts based on payments (for PaymentRecorder)
  const getDefeatedDebtIds = (): string[] => {
    if (!hasData) return [];
    return debts
      .filter(debt => {
        const debtPayments = payments.filter(p => p.debtId === debt.id);
        const totalPaid = debtPayments.reduce((sum: number, p: Payment) => sum + p.amount, 0);
        // Simple check: if total payments >= initial balance, consider defeated
        return totalPaid >= debt.balance && totalPaid > 0;
      })
      .map(d => d.id);
  };
  const defeatedDebtIds = getDefeatedDebtIds();

  return (
    <div className="min-h-screen bg-[#0A0A0C] flex flex-col">
      <StickyNav activeSection={activeSection} debtCount={debts.length} />

      <main className="flex-1 max-w-[860px] mx-auto w-full px-4 pb-16">
        {/* Hero */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
          className="pt-10 pb-4"
        >
          <h1 className="font-heading text-2xl sm:text-3xl font-bold text-white leading-tight mb-2">
            OPERACIÓN SALIDA
          </h1>
          <p className="text-white/60 text-sm sm:text-base font-subtitle max-w-md mb-4">
            Ingresa tus deudas. Recibe tu fecha exacta de libertad. Tu plan de ataque, listo.
          </p>
          <div className="flex items-center gap-4 text-[11px] text-white/30">
            <span className="flex items-center gap-1.5">
              <Shield className="w-3 h-3" /> Sin banco
            </span>
            <span className="flex items-center gap-1.5">
              <Zap className="w-3 h-3" /> 2 minutos
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3 h-3" /> Fecha exacta
            </span>
          </div>
        </motion.section>

        {/* Method Selector — at the top */}
        <MethodSelector
          method={method}
          onMethodChange={setMethod}
          hasData={hasData}
        />

        {/* Sections */}
        <DebtForm
          debts={debts}
          onAdd={handleAddDebt}
          onRemove={handleRemoveDebt}
          extraPayment={extraPayment}
          onExtraPaymentChange={setExtraPayment}
        />

        {debts.length > 0 && (
          <MissionBriefing debts={debts} extraPayment={extraPayment} method={method} />
        )}
        {hasData && (
          <>
            {/* Payment Recorder Section */}
            <section id="payments" className="pt-16 pb-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
              >
                <PaymentRecorder
                  debts={debts}
                  payments={payments}
                  onAddPayment={handleAddPayment}
                  onRemovePayment={handleRemovePayment}
                  defeatedDebtIds={defeatedDebtIds}
                />
              </motion.div>
            </section>

            {/* Attack Plan with Progress */}
            <AttackPlan debts={debts} extraPayment={extraPayment} method={method} payments={payments} />
          </>
        )}

        {/* CTA if no extra payment */}
        {debts.length > 0 && extraPayment <= 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-8 bg-[#00E5FF]/[0.04] border border-[#00E5FF]/15 rounded-xl p-5 text-center"
          >
            <DollarSign className="w-8 h-8 text-[#00E5FF] mx-auto mb-2" />
            <p className="text-sm text-white/70 mb-1">
              ¿Cuánto extra puedes aportar al mes?
            </p>
            <p className="text-xs text-white/40">
              Un monto extra significativo acelera tu salida de deudas. Arriba, en "Dinero extra al mes".
            </p>
          </motion.div>
        )}


        {/* Tip de Experto */}
        <section className="pt-16 pb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-[#FFD60A]/10 flex items-center justify-center">
                <Lightbulb className="w-5 h-5 text-[#FFD60A]" />
              </div>
              <div>
                <h2 className="font-heading text-xl font-bold text-white">Tip de Experto</h2>
                <p className="text-white/50 text-xs">Sácale el máximo provecho a esta herramienta.</p>
              </div>
            </div>

            <div className="space-y-5 bg-white/[0.02] rounded-xl p-5 border border-white/[0.05]">
              {/* Tip 1 */}
              <div className="space-y-2">
                <h3 className="text-sm font-bold text-[#00E5FF]">Registra todos tus pagos de una vez</h3>
                <p className="text-sm text-white/70 leading-relaxed">
                  No necesitas esperar a que llegue cada mes. Registra todos los pagos que planeas hacer y simplemente cambia la fecha a cuando crees que los realizarás. Si un mes no vas a pagar, no registres nada: el sistema lo detecta automáticamente y calcula los intereses que se acumulan.
                </p>
              </div>

              {/* Tip 2 */}
              <div className="space-y-2 pt-4 border-t border-white/[0.05]">
                <h3 className="text-sm font-bold text-[#FFD60A]">¿Sigues pensando en pagar solo el mínimo?</h3>
                <p className="text-sm text-white/70 leading-relaxed">
                  Si por alguna razón sigues con la idea de pagar el mínimo o de no pagar tu tarjeta, haz este ejercicio antes de decidir:
                </p>
                <p className="text-sm text-white/70 leading-relaxed">
                  En la sección de pagos, registra algunos meses como si pagaras el mínimo. <span className="text-white font-semibold">Importante: pon las fechas futuras.</span>
                </p>
                <div className="bg-white/[0.03] rounded-lg p-4 border border-white/[0.05] mt-3">
                  <p className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2">Ejemplo</p>
                  <p className="text-sm text-white/70 leading-relaxed">
                    Supongamos que hoy es 1.º de agosto de 2026 y no vas a pagar nada en tres meses. Por el mero ejercicio, registra un pago de $1 con fecha 1.º de noviembre de 2026 y observa qué pasa con los intereses.
                  </p>
                </div>
                <p className="text-sm text-white/70 leading-relaxed mt-3">
                  También funciona al revés: si sabes que vas a recibir un pago grande en 3 meses, regístralo y mira cómo impacta los intereses.
                </p>
              </div>

              {/* Tip 3 */}
              <div className="space-y-2 pt-4 border-t border-white/[0.05]">
                <h3 className="text-sm font-bold text-[#FF3B30]">No compres a meses</h3>
                <p className="text-sm text-white/70 leading-relaxed">
                  Acostúmbrate a comprar con tu tarjeta únicamente lo que puedes pagar completo. <span className="text-white font-bold">NO COMPRES A MESES.</span> Así es como crecen las deudas, y cuando menos te das cuenta, ya no puedes cubrir ni el mínimo.
                </p>
              </div>

              {/* Tip 4 */}
              <div className="space-y-2 pt-4 border-t border-white/[0.05]">
                <h3 className="text-sm font-bold text-[#30D158]">Recuerda</h3>
                <ul className="space-y-2 text-sm text-white/70">
                  <li className="flex items-start gap-2">
                    <span className="text-[#30D158] mt-0.5">•</span>
                    Los pagos se pueden borrar en cualquier momento.
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#30D158] mt-0.5">•</span>
                    Una vez que hayas pagado una deuda por completo, se inhabilita en el menú para que no vayas a registrar un pago en algo que ya lograste.
                  </li>
                </ul>
              </div>

              {/* Cierre */}
              <div className="pt-4 border-t border-white/[0.05] text-center">
                <p className="text-sm text-white/50 italic">
                  Te deseo un camino libre de intereses.
                </p>
              </div>
            </div>
          </motion.div>
        </section>

      </main>

      {/* Footer */}
      <footer className="border-t border-white/[0.04] py-5 mt-auto">
        <p className="text-center text-[11px] text-white/20">
          Operación Salida · Un producto de Nodo · Conecta tu dinero con tu meta
        </p>
      </footer>
    </div>
  );
}

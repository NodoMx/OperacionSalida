import { useRef, useState } from 'react';
import { MapView } from '@/components/Map';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Plus, Trash2 } from 'lucide-react';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { toast } from 'sonner';

interface Location {
  id: string;
  name: string;
  lat: number;
  lng: number;
}

export default function MapPage() {
  const [locations, setLocations] = useLocalStorage<Location[]>('nodo-locations', []);
  const [locationName, setLocationName] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const mapRef = useRef<google.maps.Map | null>(null);

  const handleAddLocation = () => {
    if (!locationName || !latitude || !longitude) {
      toast.error('Completa nombre, latitud y longitud.');
      return;
    }

    const newLocation: Location = {
      id: crypto.randomUUID(),
      name: locationName,
      lat: parseFloat(latitude),
      lng: parseFloat(longitude),
    };

    setLocations(prev => [...prev, newLocation]);
    setLocationName('');
    setLatitude('');
    setLongitude('');
    toast.success(`${locationName} agregada al mapa.`);
  };

  const handleRemoveLocation = (id: string) => {
    setLocations(prev => prev.filter(loc => loc.id !== id));
    toast.info('Ubicación eliminada del mapa.');
  };

  const handleMapReady = (map: google.maps.Map) => {
    mapRef.current = map;

    // Add markers for all locations
    locations.forEach(location => {
      new google.maps.marker.AdvancedMarkerElement({
        map,
        position: { lat: location.lat, lng: location.lng },
        title: location.name,
      });
    });

    // Center map on first location or default
    if (locations.length > 0) {
      map.setCenter({ lat: locations[0].lat, lng: locations[0].lng });
    }
  };

  const centerMapOnLocation = (location: Location) => {
    if (mapRef.current) {
      mapRef.current.setCenter({ lat: location.lat, lng: location.lng });
      mapRef.current.setZoom(15);
    }
  };

  const initialCenter = locations.length > 0
    ? { lat: locations[0].lat, lng: locations[0].lng }
    : { lat: 40.7128, lng: -74.006 }; // Default: New York

  return (
    <div className="min-h-screen bg-[#0A0A0C] flex flex-col">
      <nav className="sticky top-0 z-50 bg-[#0A0A0C]/90 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-[1200px] mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[#00E5FF] flex items-center justify-center">
                <MapPin className="w-4 h-4 text-[#0A0A0C]" />
              </div>
              <span className="font-heading font-bold text-[13px] text-white tracking-tight">MAPA DE SALIDA</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-[1200px] mx-auto w-full px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <div className="lg:col-span-2">
            <Card className="bg-white/[0.03] border-white/[0.05] overflow-hidden">
              <CardContent className="p-0">
                <MapView
                  initialCenter={initialCenter}
                  initialZoom={12}
                  onMapReady={handleMapReady}
                  className="w-full h-[600px]"
                />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Add Location Form */}
            <Card className="bg-white/[0.03] border-white/[0.05]">
              <CardContent className="pt-6">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-[#00E5FF]" />
                  Agregar ubicación
                </h3>

                <div className="space-y-3">
                  <div>
                    <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">
                      Nombre
                    </Label>
                    <Input
                      value={locationName}
                      onChange={e => setLocationName(e.target.value)}
                      placeholder="Ej: Hotel"
                      className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-9 text-sm rounded-lg"
                    />
                  </div>

                  <div>
                    <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">
                      Latitud
                    </Label>
                    <Input
                      value={latitude}
                      onChange={e => setLatitude(e.target.value)}
                      placeholder="40.7128"
                      type="number"
                      step="0.0001"
                      className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-9 text-sm rounded-lg"
                    />
                  </div>

                  <div>
                    <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">
                      Longitud
                    </Label>
                    <Input
                      value={longitude}
                      onChange={e => setLongitude(e.target.value)}
                      placeholder="-74.0060"
                      type="number"
                      step="0.0001"
                      className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-9 text-sm rounded-lg"
                    />
                  </div>

                  <Button
                    onClick={handleAddLocation}
                    className="w-full bg-[#00E5FF] text-[#0A0A0C] font-bold hover:bg-[#00E5FF]/90 h-9 text-sm rounded-lg"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Agregar
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Locations List */}
            {locations.length > 0 && (
              <Card className="bg-white/[0.03] border-white/[0.05]">
                <CardContent className="pt-6">
                  <h3 className="text-sm font-bold text-white mb-4">
                    Ubicaciones ({locations.length})
                  </h3>

                  <div className="space-y-2">
                    {locations.map(location => (
                      <div
                        key={location.id}
                        className="flex items-center justify-between bg-white/[0.03] rounded-lg px-3 py-2 border border-white/[0.05] hover:bg-white/[0.05] transition-colors cursor-pointer"
                        onClick={() => centerMapOnLocation(location)}
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-white truncate">
                            {location.name}
                          </p>
                          <p className="text-[10px] text-white/40">
                            {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                          </p>
                        </div>
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            handleRemoveLocation(location.id);
                          }}
                          className="text-white/20 hover:text-[#FF3B30] transition-colors p-1 rounded-md hover:bg-[#FF3B30]/10"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/[0.04] py-5 mt-auto">
        <p className="text-center text-[11px] text-white/20">
          Mapa de Salida · Visualiza todas las ubicaciones de tu evento grupal
        </p>
      </footer>
    </div>
  );
}

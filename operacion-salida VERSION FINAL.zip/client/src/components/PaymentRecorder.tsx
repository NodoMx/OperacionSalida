import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/debt-calculator';
import { toast } from 'sonner';
import type { Debt } from '@/lib/debt-calculator';
import type { Payment } from '@/types/payments';

interface PaymentRecorderProps {
  debts: Debt[];
  payments: Payment[];
  onAddPayment: (payment: Payment) => void;
  onRemovePayment: (paymentId: string) => void;
  defeatedDebtIds?: string[];
}

export function PaymentRecorder({
  debts,
  payments,
  onAddPayment,
  onRemovePayment,
  defeatedDebtIds = [],
}: PaymentRecorderProps) {
  const activeDebts = debts.filter(d => !defeatedDebtIds.includes(d.id));
  const [selectedDebtId, setSelectedDebtId] = useState<string>(activeDebts[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleAddPayment = () => {
    if (!selectedDebtId || !amount) {
      toast.error('Selecciona una deuda e ingresa un monto.');
      return;
    }

    const debt = debts.find(d => d.id === selectedDebtId);
    if (!debt) {
      toast.error('Deuda no encontrada.');
      return;
    }

    const payment: Payment = {
      id: crypto.randomUUID(),
      debtId: selectedDebtId,
      amount: parseFloat(amount),
      date: new Date(date),
      createdAt: new Date(),
    };

    onAddPayment(payment);
    setAmount('');
    setDate(new Date().toISOString().split('T')[0]);
    toast.success(`Pago de ${formatCurrency(parseFloat(amount))} registrado para ${debt.name}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleAddPayment();
  };

  // Group payments by debt
  const paymentsByDebt = debts.map(debt => {
    const debtPayments = payments.filter(p => p.debtId === debt.id);
    const totalPaid = debtPayments.reduce((sum, p) => sum + p.amount, 0);
    return { debt, payments: debtPayments, totalPaid };
  });

  const totalPaymentsAmount = payments.reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-[#00E5FF]/10 flex items-center justify-center">
          <CreditCard className="w-5 h-5 text-[#00E5FF]" />
        </div>
        <div>
          <h2 className="font-heading text-xl font-bold text-white">Registro de Pagos</h2>
          <p className="text-white/50 text-xs">Registra los pagos que realizarás para actualizar el progreso.</p>
        </div>
      </div>

      {/* Payment Form */}
      <Card className="bg-white/[0.03] border-white/[0.05]">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            <div>
              <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Deuda</Label>
              <select
                value={selectedDebtId}
                onChange={e => setSelectedDebtId(e.target.value)}
                className="w-full bg-white/[0.04] border border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg px-3"
              >
                {debts.map(debt => {
                  const isDefeated = defeatedDebtIds.includes(debt.id);
                  return (
                  <option key={debt.id} value={debt.id} className="bg-[#0A0A0C]" disabled={isDefeated}>
                    {debt.name}{isDefeated ? ' ✓ PAGADA' : ''}
                  </option>
                  );
                })}
              </select>
            </div>

            <div>
              <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Monto ($)</Label>
              <Input
                value={amount}
                onChange={e => setAmount(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="500"
                type="number"
                className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg"
              />
            </div>

            <div>
              <Label className="text-[11px] text-white/40 mb-1.5 block font-subtitle">Fecha</Label>
              <Input
                value={date}
                onChange={e => setDate(e.target.value)}
                onKeyDown={handleKeyDown}
                type="date"
                className="bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 h-10 text-sm rounded-lg"
              />
            </div>
          </div>

          <Button
            onClick={handleAddPayment}
            className="w-full bg-[#00E5FF] text-[#0A0A0C] font-bold hover:bg-[#00E5FF]/90 h-10 text-sm rounded-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Registrar Pago
          </Button>
        </CardContent>
      </Card>

      {/* Payments Summary */}
      {payments.length > 0 && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="space-y-3"
        >
          {/* Global Summary */}
          <Card className="bg-[#30D158]/[0.04] border-[#30D158]/15">
            <CardContent className="pt-4 pb-3 px-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-white">Total pagado</p>
                <p className="text-lg font-heading font-bold text-[#30D158]">
                  {formatCurrency(totalPaymentsAmount)}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Payments by Debt */}
          {paymentsByDebt.map(({ debt, payments: debtPayments, totalPaid }) => {
            if (debtPayments.length === 0) return null;

            return (
              <motion.div
                key={debt.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/[0.03] rounded-lg p-4 border border-white/[0.05] space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-white">{debt.name}</p>
                    <p className="text-[11px] text-white/40">
                      {debtPayments.length} pago{debtPayments.length !== 1 ? 's' : ''} registrado{debtPayments.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <Badge className="bg-[#30D158]/10 text-[#30D158] border border-[#30D158]/20">
                    {formatCurrency(totalPaid)}
                  </Badge>
                </div>

                {/* Individual Payments */}
                <div className="space-y-2 pt-2 border-t border-white/[0.05]">
                  {debtPayments.map((payment, idx) => (
                    <motion.div
                      key={payment.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="flex items-center justify-between bg-white/[0.02] rounded px-3 py-2"
                    >
                      <div className="flex-1">
                        <p className="text-xs text-white">
                          {formatCurrency(payment.amount)}
                        </p>
                        <p className="text-[10px] text-white/40">
                          {typeof payment.date === 'string' 
                            ? payment.date 
                            : new Date(payment.date).toLocaleDateString('es-MX')}
                        </p>
                      </div>
                      <button
                        onClick={() => onRemovePayment(payment.id)}
                        className="text-white/20 hover:text-[#FF3B30] transition-colors p-1 rounded hover:bg-[#FF3B30]/10"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}
    </div>
  );
}

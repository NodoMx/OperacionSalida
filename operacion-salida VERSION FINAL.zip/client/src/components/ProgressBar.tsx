import { formatCurrency } from '@/lib/debt-calculator';
import { Trophy } from 'lucide-react';

interface ProgressBarDetailedProps {
  initialBalance: number;
  interestGenerated: number;
  paymentApplied: number;
  interestPaid: number;
  capitalPaid: number;
  finalBalance: number;
  label?: string;
  debtName?: string;
  isDefeated?: boolean;
}

export function ProgressBar({
  initialBalance,
  interestGenerated,
  paymentApplied,
  interestPaid,
  capitalPaid,
  finalBalance,
  label,
  debtName,
  isDefeated,
}: ProgressBarDetailedProps) {
  // Ensure numbers are consistent:
  // interestPaid + capitalPaid = paymentApplied
  // interestGenerated = interestPaid (what was generated is what was paid to interest)
  const correctedInterestPaid = interestPaid;
  const correctedCapitalPaid = paymentApplied - correctedInterestPaid;

  // Calculate percentages for the visual bar
  // The bar shows: green (capital paid) | yellow (interest paid) | red (remaining balance)
  const totalValue = initialBalance + interestGenerated;
  const capitalPercent = totalValue > 0 ? (Math.max(0, correctedCapitalPaid) / totalValue) * 100 : 0;
  const interestPercent = totalValue > 0 ? (correctedInterestPaid / totalValue) * 100 : 0;
  const remainingPercent = totalValue > 0 ? (finalBalance / totalValue) * 100 : 0;

  // VICTORIA state
  if (isDefeated || finalBalance <= 0) {
    return (
      <div className="space-y-3">
        <div className="bg-[#30D158]/10 border border-[#30D158]/30 rounded-xl p-6 text-center">
          <Trophy className="w-10 h-10 text-[#30D158] mx-auto mb-3" />
          <h3 className="text-xl font-heading font-bold text-[#30D158] mb-1">VICTORIA</h3>
          <p className="text-sm text-white/60">
            {debtName ? `${debtName} ha sido eliminada.` : 'Deuda eliminada.'}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-3 text-[11px]">
            <div>
              <p className="text-white/40">Total pagado</p>
              <p className="text-[#30D158] font-bold">{formatCurrency(paymentApplied)}</p>
            </div>
            <div>
              <p className="text-white/40">Intereses pagados</p>
              <p className="text-[#FFD60A] font-bold">{formatCurrency(correctedInterestPaid)}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Detailed breakdown table */}
      <div className="space-y-2 text-sm">
        {/* Saldo inicial */}
        <div className="flex items-center justify-between border-b border-white/[0.05] pb-2">
          <span className="text-white/70">Saldo inicial</span>
          <span className="text-white font-semibold">{formatCurrency(initialBalance)}</span>
        </div>

        {/* Pago aplicado */}
        <div className="flex items-center justify-between border-b border-white/[0.05] pb-2">
          <span className="text-white/70">Pago aplicado</span>
          <span className="text-[#30D158] font-semibold">{formatCurrency(paymentApplied)}</span>
        </div>

        {/* Desglose del pago - must add up to paymentApplied */}
        <div className="ml-4 space-y-1 text-[11px]">
          <div className="flex items-center justify-between">
            <span className="text-white/50">— de eso, a interés</span>
            <span className="text-[#FFD60A]">{formatCurrency(correctedInterestPaid)}</span>
          </div>
          <div className="flex items-center justify-between border-b border-white/[0.05] pb-2">
            <span className="text-white/50">— de eso, a capital</span>
            <span className="text-[#30D158]">{formatCurrency(Math.max(0, correctedCapitalPaid))}</span>
          </div>
        </div>

        {/* Saldo final */}
        <div className="flex items-center justify-between pt-2">
          <span className="text-white font-semibold">Saldo final</span>
          <span className="text-[#FF3B30] font-bold">{formatCurrency(finalBalance)}</span>
        </div>
      </div>

      {/* Visual Progress Bar */}
      <div className="relative h-8 bg-white/[0.04] rounded-lg overflow-hidden border border-white/[0.05] mt-4">
        {/* Capital Paid (Green) */}
        {capitalPercent > 0 && (
          <div
            className="absolute inset-y-0 left-0 bg-[#30D158] transition-all duration-500"
            style={{ width: `${capitalPercent}%` }}
            title={`Capital pagado: ${formatCurrency(Math.max(0, correctedCapitalPaid))}`}
          />
        )}

        {/* Interest (Yellow) */}
        {interestPercent > 0 && (
          <div
            className="absolute inset-y-0 bg-[#FFD60A] transition-all duration-500"
            style={{
              left: `${capitalPercent}%`,
              width: `${interestPercent}%`,
            }}
            title={`Interés: ${formatCurrency(correctedInterestPaid)}`}
          />
        )}

        {/* Remaining (Red) */}
        {remainingPercent > 0 && (
          <div
            className="absolute inset-y-0 bg-[#FF3B30] transition-all duration-500"
            style={{
              left: `${capitalPercent + interestPercent}%`,
              width: `${remainingPercent}%`,
            }}
            title={`Saldo restante: ${formatCurrency(finalBalance)}`}
          />
        )}

        {/* Text overlay */}
        <div className="absolute inset-0 flex items-center justify-between px-3 text-[10px] font-bold text-white pointer-events-none">
          {capitalPercent > 12 && (
            <span className="text-white drop-shadow-lg">{formatCurrency(Math.max(0, correctedCapitalPaid))}</span>
          )}
          {interestPercent > 12 && (
            <span className="text-[#0A0A0C] drop-shadow-lg">{formatCurrency(correctedInterestPaid)}</span>
          )}
          {remainingPercent > 12 && (
            <span className="text-white drop-shadow-lg">{formatCurrency(finalBalance)}</span>
          )}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 text-[10px] mt-2">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-[#30D158]" />
          <span className="text-white/60">Capital</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-[#FFD60A]" />
          <span className="text-white/60">Interés</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-[#FF3B30]" />
          <span className="text-white/60">Saldo</span>
        </div>
      </div>
    </div>
  );
}

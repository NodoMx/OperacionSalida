import { describe, it, expect } from 'vitest';
import {
  calculatePayoff,
  getDebtOrder,
  formatCurrency,
  formatNumber,
  formatDate,
  type Debt,
} from './debt-calculator';

describe('debt-calculator', () => {
  describe('calculatePayoff', () => {
    it('should calculate payoff with snowball method', () => {
      const debts: Debt[] = [
        { id: '1', name: 'Credit Card 1', balance: 5000, minPayment: 150, interestRate: 20 },
        { id: '2', name: 'Credit Card 2', balance: 10000, minPayment: 200, interestRate: 18 },
      ];

      const result = calculatePayoff(debts, 500, 'snowball');

      expect(result.totalMonths).toBeGreaterThan(0);
      expect(result.totalMonths).toBeLessThanOrEqual(360);
      expect(result.totalInterestPaid).toBeGreaterThan(0);
      expect(result.freedomDate).toBeInstanceOf(Date);
      expect(result.order.length).toBeLessThanOrEqual(debts.length);
      expect(result.monthlyBalances.length).toBeGreaterThan(0);
    });

    it('should calculate payoff with avalanche method', () => {
      const debts: Debt[] = [
        { id: '1', name: 'Credit Card 1', balance: 5000, minPayment: 150, interestRate: 20 },
        { id: '2', name: 'Credit Card 2', balance: 10000, minPayment: 200, interestRate: 18 },
      ];

      const result = calculatePayoff(debts, 500, 'avalanche');

      expect(result.totalMonths).toBeGreaterThan(0);
      expect(result.totalInterestPaid).toBeGreaterThan(0);
      expect(result.savings).toBeGreaterThanOrEqual(0);
    });

    it('should save more money with avalanche than snowball', () => {
      const debts: Debt[] = [
        { id: '1', name: 'Debt 1', balance: 5000, minPayment: 150, interestRate: 25 },
        { id: '2', name: 'Debt 2', balance: 10000, minPayment: 200, interestRate: 15 },
      ];

      const snowballResult = calculatePayoff(debts, 500, 'snowball');
      const avalancheResult = calculatePayoff(debts, 500, 'avalanche');

      // Avalanche should typically save more or equal interest
      expect(avalancheResult.totalInterestPaid).toBeLessThanOrEqual(snowballResult.totalInterestPaid);
    });

    it('should handle empty debt array', () => {
      const debts: Debt[] = [];
      const result = calculatePayoff(debts, 500, 'snowball');

      expect(result.totalMonths).toBe(0);
      expect(result.totalInterestPaid).toBe(0);
      expect(result.order.length).toBe(0);
    });

    it('should handle zero extra payment', () => {
      const debts: Debt[] = [
        { id: '1', name: 'Debt 1', balance: 5000, minPayment: 150, interestRate: 20 },
      ];

      const result = calculatePayoff(debts, 0, 'snowball');

      // With only minimum payments, it should take longer
      expect(result.totalMonths).toBeGreaterThan(0);
    });
  });

  describe('getDebtOrder', () => {
    it('should order debts by balance for snowball', () => {
      const debts: Debt[] = [
        { id: '1', name: 'Debt 1', balance: 10000, minPayment: 200, interestRate: 20 },
        { id: '2', name: 'Debt 2', balance: 5000, minPayment: 150, interestRate: 18 },
        { id: '3', name: 'Debt 3', balance: 15000, minPayment: 300, interestRate: 22 },
      ];

      const order = getDebtOrder(debts, 'snowball');

      expect(order[0].debt.id).toBe('2'); // 5000 (smallest)
      expect(order[1].debt.id).toBe('1'); // 10000
      expect(order[2].debt.id).toBe('3'); // 15000 (largest)
    });

    it('should order debts by interest rate for avalanche', () => {
      const debts: Debt[] = [
        { id: '1', name: 'Debt 1', balance: 10000, minPayment: 200, interestRate: 20 },
        { id: '2', name: 'Debt 2', balance: 5000, minPayment: 150, interestRate: 18 },
        { id: '3', name: 'Debt 3', balance: 15000, minPayment: 300, interestRate: 22 },
      ];

      const order = getDebtOrder(debts, 'avalanche');

      expect(order[0].debt.id).toBe('3'); // 22% (highest)
      expect(order[1].debt.id).toBe('1'); // 20%
      expect(order[2].debt.id).toBe('2'); // 18% (lowest)
    });
  });

  describe('formatCurrency', () => {
    it('should format currency in MXN', () => {
      const formatted = formatCurrency(15000);
      expect(formatted).toContain('$');
      expect(formatted).toContain('15');
    });

    it('should handle zero', () => {
      const formatted = formatCurrency(0);
      expect(formatted).toContain('$');
      expect(formatted).toContain('0');
    });

    it('should handle negative values', () => {
      const formatted = formatCurrency(-5000);
      expect(formatted).toContain('$');
    });
  });

  describe('formatNumber', () => {
    it('should format numbers without currency symbol', () => {
      const formatted = formatNumber(15000);
      expect(formatted).toBe('15,000');
    });

    it('should handle decimals', () => {
      const formatted = formatNumber(15000.5);
      expect(formatted).toBe('15,001'); // Rounded
    });
  });

  describe('formatDate', () => {
    it('should format date in Spanish', () => {
      const date = new Date(2026, 11, 25); // December 25, 2026
      const formatted = formatDate(date);
      expect(formatted).toContain('25');
      expect(formatted).toContain('DIC');
      expect(formatted).toContain('2026');
    });

    it('should handle all months', () => {
      const months = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
      for (let i = 0; i < 12; i++) {
        const date = new Date(2026, i, 15);
        const formatted = formatDate(date);
        expect(formatted).toContain(months[i]);
      }
    });
  });
});

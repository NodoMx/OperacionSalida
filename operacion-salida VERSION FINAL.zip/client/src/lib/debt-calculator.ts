// Debt payoff calculator utilities
// Implements month-by-month simulation matching the Excel "Plan Adiós Deuda" logic exactly

export interface Debt {
  id: string;
  name: string;
  balance: number; // initial balance
  minPayment: number; // monthly minimum payment
  interestRate: number; // annual rate as percentage (e.g. 35 = 35%)
  createdAt?: string; // ISO date string when the debt was registered
}

export interface PayoffResult {
  totalMonths: number;
  totalInterestPaid: number;
  freedomDate: Date;
  order: DebtOrder[];
  comparisonWithMin: {
    months: number;
    interestPaid: number;
  };
  savings: number;
  monthsSaved: number;
  monthlyBalances: MonthSnapshot[]; // for chart/graph
}

export interface DebtOrder {
  id: string;
  name: string;
  balance: number;
  interestRate: number;
  minPayment: number;
  monthToDefeat: number;
  totalPaid: number;
}

export interface MonthSnapshot {
  month: number;
  date: Date;
  totalBalance: number;
  totalInterestPaid: number;
  debtBalances: { id: string; balance: number }[];
}

const MAX_MONTHS = 360; // 30 years, same as Excel
const THRESHOLD = 0.005; // same as Excel

/**
 * Core simulation engine: runs month-by-month for up to 360 months.
 * Implements the exact "Efecto Dominó" from the Excel.
 *
 * Logic per month:
 * 1. Apply interest to all active debts: balance *= (1 + monthly_rate)
 * 2. Identify which debt is the primary target (first in order with balance > threshold)
 * 3. Calculate total minimum payments for active debts
 * 4. Extra = extraPayment (user input) — this is the "dinero extra" field
 * 5. Pay each active debt: minPayment, except the target gets minPayment + all extra + freed payments
 * 6. Freed payments = sum of minPayments from debts that are already defeated
 * 7. Track when each debt reaches 0
 */
function simulateMonthByMonth(
  debts: Debt[],
  extraPayment: number,
  order: Debt[] // the attack order (sorted by strategy)
): {
  totalMonths: number;
  totalInterestPaid: number;
  order: DebtOrder[];
  monthlyBalances: MonthSnapshot[];
} {
  const working = debts.map(d => ({
    id: d.id,
    name: d.name,
    balance: d.balance,
    minPayment: d.minPayment,
    interestRate: d.interestRate,
    defeated: false,
    totalPaid: 0,
  }));

  // Build order map: for each debt, what position in attack order?
  const orderPosition = new Map<string, number>();
  order.forEach((d, i) => orderPosition.set(d.id, i));

  let totalInterestPaid = 0;
  const debtOrder: DebtOrder[] = [];
  const monthlyBalances: MonthSnapshot[] = [];

  // If all debts already at 0
  if (!working.some(d => d.balance > THRESHOLD)) {
    return {
      totalMonths: 0,
      totalInterestPaid: 0,
      order: [],
      monthlyBalances: [],
    };
  }

  for (let month = 1; month <= MAX_MONTHS; month++) {
    // Step 1: Apply interest to all active debts
    for (const d of working) {
      if (d.balance > THRESHOLD) {
        const monthlyRate = d.interestRate / 100 / 12;
        const interest = d.balance * monthlyRate;
        totalInterestPaid += interest;
        d.balance += interest;
      }
    }

    // Step 2: Identify the primary target
    let primaryTargetId: string | null = null;
    for (const debt of order) {
      const w = working.find(d => d.id === debt.id);
      if (w && w.balance > THRESHOLD) {
        primaryTargetId = debt.id;
        break;
      }
    }

    // Step 3: Calculate freed payments from defeated debts
    const freedPayments = working
      .filter(d => d.balance <= THRESHOLD)
      .reduce((sum, d) => sum + d.minPayment, 0);

    // Step 4: Pay each active debt
    for (const d of working) {
      if (d.balance <= THRESHOLD) continue;

      let payment = d.minPayment;

      // The primary target gets ALL the extra + freed payments
      if (d.id === primaryTargetId) {
        payment = d.balance; // Try to pay it all off
        if (payment > d.minPayment + extraPayment + freedPayments) {
          payment = d.minPayment + extraPayment + freedPayments;
        }
      }

      // Don't overpay
      if (payment > d.balance) {
        payment = d.balance;
      }

      d.totalPaid += payment;
      d.balance -= payment;

      if (d.balance < 0) d.balance = 0;

      // Check if just defeated
      if (d.balance <= THRESHOLD && !d.defeated) {
        d.defeated = true;
        debtOrder.push({
          id: d.id,
          name: d.name,
          balance: 0,
          interestRate: d.interestRate,
          minPayment: d.minPayment,
          monthToDefeat: month,
          totalPaid: d.totalPaid,
        });
      }
    }

    // Snapshot
    const totalBalance = working.reduce((sum, d) => sum + d.balance, 0);
    const date = new Date();
    date.setMonth(date.getMonth() + month);

    monthlyBalances.push({
      month,
      date,
      totalBalance,
      totalInterestPaid,
      debtBalances: working.map(d => ({ id: d.id, balance: d.balance })),
    });

    // Check if all defeated
    if (!working.some(d => d.balance > THRESHOLD)) {
      return {
        totalMonths: month,
        totalInterestPaid,
        order: debtOrder,
        monthlyBalances,
      };
    }
  }

  // If we hit 360 months and still have balance
  const totalBalance = working.reduce((sum, d) => sum + d.balance, 0);
  return {
    totalMonths: MAX_MONTHS,
    totalInterestPaid,
    order: debtOrder,
    monthlyBalances,
  };
}

/**
 * Simulate paying only minimums (for comparison)
 */
function simulateMinOnly(debts: Debt[]): { months: number; interestPaid: number } {
  const initialTotal = debts.reduce((s, d) => s + d.balance, 0);
  const working = debts.map(d => ({
    id: d.id,
    balance: d.balance,
    minPayment: d.minPayment,
    interestRate: d.interestRate,
  }));

  let totalInterest = 0;
  let month = 0;
  let growingMonths = 0;

  while (working.some(d => d.balance > THRESHOLD) && month < MAX_MONTHS) {
    month++;

    // Check if total balance is growing (min < interest)
    const totalBalanceBefore = working.reduce((s, d) => s + d.balance, 0);
    const totalMinPayments = working.reduce((s, d) => s + d.minPayment, 0);
    const totalInterestThisMonth = working
      .filter(d => d.balance > THRESHOLD)
      .reduce((s, d) => s + d.balance * (d.interestRate / 100 / 12), 0);

    if (totalInterestThisMonth > totalMinPayments && totalBalanceBefore > initialTotal * 3) {
      growingMonths++;
      if (growingMonths > 6) {
        return { months: MAX_MONTHS + 1, interestPaid: totalInterest };
      }
    } else {
      growingMonths = 0;
    }

    for (const d of working) {
      if (d.balance > THRESHOLD) {
        const monthlyRate = d.interestRate / 100 / 12;
        const interest = d.balance * monthlyRate;
        totalInterest += interest;
        d.balance += interest;

        let payment = d.minPayment;
        if (payment > d.balance) payment = d.balance;
        d.balance -= payment;
        if (d.balance < 0) d.balance = 0;
      }
    }

    // Safety: if total balance exceeds 10x initial, stop
    const totalBalanceAfter = working.reduce((s, d) => s + d.balance, 0);
    if (totalBalanceAfter > initialTotal * 10) {
      return { months: month, interestPaid: totalInterest };
    }
  }

  return { months: month, interestPaid: totalInterest };
}

export function calculatePayoff(
  debts: Debt[],
  extraPayment: number,
  method: 'snowball' | 'avalanche'
): PayoffResult {
  // Create attack order
  let order: Debt[];
  if (method === 'snowball') {
    order = [...debts].sort((a, b) => a.balance - b.balance);
  } else {
    order = [...debts].sort((a, b) => b.interestRate - a.interestRate);
  }

  // Simulate
  const simulation = simulateMonthByMonth(debts, extraPayment, order);
  const minOnly = simulateMinOnly(debts);

  const freedomDate = new Date();
  freedomDate.setMonth(freedomDate.getMonth() + simulation.totalMonths);

  const monthlyPayment = debts.reduce((sum, d) => sum + d.minPayment, 0) + extraPayment;

  return {
    totalMonths: simulation.totalMonths,
    totalInterestPaid: simulation.totalInterestPaid,
    freedomDate,
    order: simulation.order,
    comparisonWithMin: minOnly,
    savings: minOnly.interestPaid - simulation.totalInterestPaid,
    monthsSaved: minOnly.months - simulation.totalMonths,
    monthlyBalances: simulation.monthlyBalances,
  };
}

/**
 * Calculate the ordering of debts for display (which gets attacked first)
 */
export function getDebtOrder(
  debts: Debt[],
  method: 'snowball' | 'avalanche'
): { debt: Debt; rank: number }[] {
  const sorted = method === 'snowball'
    ? [...debts].sort((a, b) => a.balance - b.balance)
    : [...debts].sort((a, b) => b.interestRate - a.interestRate);

  return sorted.map((d, i) => ({ debt: d, rank: i + 1 }));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(amount: number): string {
  return new Intl.NumberFormat('es-MX', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: Date): string {
  const months = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
  return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
}
